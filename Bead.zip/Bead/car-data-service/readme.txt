REST NetBean-be �rva

Adatb�zis config:
"car-data-service\src\main\java\hu\zip\car\data\service\config\DataBaseConfig.java"-ba tudjuk be�ll�tani.
Az adatb�zisnak MYSQL lett v�ve �s a DB script is ahozz lett irva meg.
Az adatb�zis scriptet �s a DB confiogot miel�tt ind�tjuk meg kell csin�lni m�sk�pen nem fog elind�lni a szerver.

A jar mag�ban tartalmazza a Tomcat szervert is.
A szerver ind�t�ssa megtehet� �gy hogy a buildelt jar-ra 2x kattintunk �s elind�l a szerver.
Vagy a source-ba az Application.java oszt�lyt futatjuk a NetBean-ben.

A szerver el�r�se:
Gy�k�r c�m: http://localhost:8444/api/
A gy�k�r c�men �rhet� el a REST.

Lehets�geg h�v�sokra p�lda:

http://localhost:8444/api/jarmu?id=7
http://localhost:8444/api/tulajdonos?id=7
http://localhost:8444/api/jarmuEletut?id=7
http://localhost:8444/api/jarmuKiegeszitoData?id=7
http://localhost:8444/api/xtJarmuTulajdonos?id=7
http://localhost:8444/api/tulajdonosJarmui?id=7

T�bb lehets�ges param�ter is van. Azokat l�sd a "car-data-service\src\main\java\hu\zip\car\data\service\rest\CarDataServiceEndpoint.java"-ban.

A test asdtok a testadatok_SQL.sql f�jlban tal�lhat�ak. "car-data-service\testadatok_SQL.sql"
 
Felhaszn�lt dolgok:
NetBean IDE 8.2
Spring-Boot 1.2.1
MYSQL DB a leg�jabb
Spring Boot Jersey Blank Project (from https://github.com/making/spring-boot-jersey-blank) maven arhitect.

