package hu.zip.car.data.service.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import hu.zip.car.data.service.dto.VehicleAccessoryDataDTO;
import hu.zip.car.data.util.StringUtils;

@Service
public class VehicleAccessoryDataDao {

	private static final Logger LOG = LoggerFactory.getLogger(VehicleDao.class);
	public static final String TABLE_NAME = "JARMU_KIEGESZITO_DATA";
	public static final String COLUMN_ID = "ID";
	public static final String COLUMN_VEHICLE = "JARMU_ID";
	public static final String COLUMN_ACCESSORY_KEY = "KULCS";
	public static final String COLUMN_ACCESSORY_KEY_DENOMINATION = "KULCS_MEGNEVEZES";
	public static final String COLUMN_ACCESSORY_VALUE = "KULCS_ERTEK";
	public static final String COLUMN_CRD = "CRD";
	public static final String COLUMN_CRU = "CRU";
	public static final String COLUMN_LMD = "LMD";
	public static final String COLUMN_LMU = "LMU";
	public static final String COLUMN_ACTIVE = "AKTIV";

	@Qualifier("mysqlConncetion")
	@Autowired
	private Connection con;

	@Autowired
	private VehicleDao vehicleDao;

	/**
	 *
	 * @param id
	 *            Tabla azonosito.
	 * @param vehicleId
	 *            JARMU azonosito.
	 * @param accessoryKey
	 *            Meta adat kulcs.
	 * @param accessoryKeyDenomination
	 *            Meta adat kulcshoz tartozo megnevezes.
	 * @param accessoryValue
	 *            Meta adat erteke.
	 * @return A keresesi felteteleknek megfelelo meta adatok a jarmuvekhez.
	 */
	public List<VehicleAccessoryDataDTO> findByParams(Long id, Long vehicleId, String accessoryKey, String accessoryKeyDenomination, String accessoryValue) {
		Statement statement = null;
		try {
			statement = this.con.createStatement();
			StringBuilder sb = new StringBuilder();
			sb.append("SELECT * FROM ").append(VehicleAccessoryDataDao.TABLE_NAME);

			if (Objects.nonNull(id) || Objects.nonNull(vehicleId)//
					|| Objects.nonNull(StringUtils.trimToNull(accessoryKey))//
					|| Objects.nonNull(StringUtils.trimToNull(accessoryKeyDenomination))//
					|| Objects.nonNull(StringUtils.trimToNull(accessoryValue))//
			) {
				sb.append(" WHERE ");
			}
			if (Objects.nonNull(id)) {
				sb.append(VehicleAccessoryDataDao.COLUMN_ID).append("=").append(id);
				sb.append(" AND ");
			}
			if (Objects.nonNull(vehicleId)) {
				sb.append(VehicleAccessoryDataDao.COLUMN_VEHICLE).append("=").append(vehicleId);
				sb.append(" AND ");
			}
			if (Objects.nonNull(StringUtils.trimToNull(accessoryKey))) {
				sb.append(VehicleAccessoryDataDao.COLUMN_ACCESSORY_KEY).append(" LIKE \"%").append(accessoryKey).append("%\"");
				sb.append(" AND ");
			}
			if (Objects.nonNull(StringUtils.trimToNull(accessoryKeyDenomination))) {
				sb.append(VehicleAccessoryDataDao.COLUMN_ACCESSORY_KEY_DENOMINATION).append(" LIKE \"%")//
						.append(accessoryKeyDenomination).append("%\"");
				sb.append(" AND ");
			}
			if (Objects.nonNull(StringUtils.trimToNull(accessoryValue))) {
				sb.append(VehicleAccessoryDataDao.COLUMN_ACCESSORY_VALUE).append(" LIKE \"%").append(accessoryValue).append("%\"");

			}

			String sql = sb.toString();
			if (sql.endsWith(" AND ")) {
				sql = sql.substring(0, sql.length() - 5);
			}
			VehicleAccessoryDataDao.LOG.info("SQL command: {}", sql);
			ResultSet resultSet = statement.executeQuery(sql);
			List<VehicleAccessoryDataDTO> resultList = new ArrayList<>();
			while (resultSet.next()) {
				VehicleAccessoryDataDTO dto = new VehicleAccessoryDataDTO();

				dto.setId(resultSet.getLong(VehicleAccessoryDataDao.COLUMN_ID));
				dto.setVehicle(this.vehicleDao.findOne(resultSet.getLong(VehicleAccessoryDataDao.COLUMN_VEHICLE)));
				dto.setAccessoryKey(resultSet.getString(VehicleAccessoryDataDao.COLUMN_ACCESSORY_KEY));
				dto.setAccessoryKeyDenomination(resultSet.getString(VehicleAccessoryDataDao.COLUMN_ACCESSORY_KEY_DENOMINATION));
				dto.setAccessoryValue(resultSet.getString(VehicleAccessoryDataDao.COLUMN_ACCESSORY_VALUE));
				dto.setCrd(resultSet.getDate(VehicleAccessoryDataDao.COLUMN_CRD));
				dto.setCru(resultSet.getString(VehicleAccessoryDataDao.COLUMN_CRU));
				dto.setLmd(resultSet.getDate(VehicleAccessoryDataDao.COLUMN_LMD));
				dto.setLmu(resultSet.getString(VehicleAccessoryDataDao.COLUMN_LMU));
				dto.setActive(resultSet.getBoolean(VehicleAccessoryDataDao.COLUMN_ACTIVE));

				resultList.add(dto);
			}
			return resultList;
		} catch (SQLException e) {
			VehicleAccessoryDataDao.LOG.error(e.getMessage(), e);

		} finally {
			if (statement != null) {
				try {
					statement.close();
				} catch (SQLException e) {
					VehicleAccessoryDataDao.LOG.error(e.getMessage(), e);
				}
			}
		}
		return null;
	}
}
