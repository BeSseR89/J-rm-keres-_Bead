package hu.zip.car.data.service.dto;

import java.util.Date;

public class VehicleAccessoryDataDTO {

	/**
	 * A tábla egydi azonosítója.
	 */
	private Long id;
	private VehicleDTO vehicle;
	private String accessoryKey;
	private String accessoryKeyDenomination;
	private String accessoryValue;

	/**
	 * A rekord létrehozásának dátuma.
	 */
	private Date crd;
	/**
	 * A rekordot létrehozó felhasználó azonosítója.
	 */
	private String cru;
	/**
	 * A rekord utilsó módosításának dátuma.
	 */
	private Date lmd;
	/**
	 * A rekordot utoljára módosító felhasználó azonosítója.
	 */
	private String lmu;
	/**
	 * A rekord aktív-e?
	 */
	private boolean active;

	public String getAccessoryKey() {
		return this.accessoryKey;
	}

	public String getAccessoryKeyDenomination() {
		return this.accessoryKeyDenomination;
	}

	public String getAccessoryValue() {
		return this.accessoryValue;
	}

	public Date getCrd() {
		return this.crd;
	}

	public String getCru() {
		return this.cru;
	}

	public Long getId() {
		return this.id;
	}

	public Date getLmd() {
		return this.lmd;
	}

	public String getLmu() {
		return this.lmu;
	}

	public VehicleDTO getVehicle() {
		return this.vehicle;
	}

	public boolean isActive() {
		return this.active;
	}

	public void setAccessoryKey(String accessoryKey) {
		this.accessoryKey = accessoryKey;
	}

	public void setAccessoryKeyDenomination(String accessoryKeyDenomination) {
		this.accessoryKeyDenomination = accessoryKeyDenomination;
	}

	public void setAccessoryValue(String accessoryValue) {
		this.accessoryValue = accessoryValue;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public void setCrd(Date crd) {
		this.crd = crd;
	}

	public void setCru(String cru) {
		this.cru = cru;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setLmd(Date lmd) {
		this.lmd = lmd;
	}

	public void setLmu(String lmu) {
		this.lmu = lmu;
	}

	public void setVehicle(VehicleDTO vehicle) {
		this.vehicle = vehicle;
	}

}
