package hu.zip.car.data.service.config;

import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableAsync;

import com.vaadin.server.VaadinServlet;
import com.vaadin.spring.server.SpringVaadinServlet;

@Configuration
@EnableAsync
@EnableAutoConfiguration
public class ApplicationConfig {

	@Bean
	public VaadinServlet vaadinServlet() {
		return new SpringVaadinServlet();
	}

}