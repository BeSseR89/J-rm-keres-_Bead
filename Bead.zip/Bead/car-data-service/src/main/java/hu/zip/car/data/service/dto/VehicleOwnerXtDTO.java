package hu.zip.car.data.service.dto;

import java.io.Serializable;
import java.util.Date;

public class VehicleOwnerXtDTO implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 * A tábla egydi azonosítója.
	 */
	private Long id;
	private VehicleDTO vehicle;
	private OwnerDTO owner;
	private Date from;
	private Date to;

	/**
	 * A rekord létrehozásának dátuma.
	 */
	private Date crd;
	/**
	 * A rekordot létrehozó felhasználó azonosítója.
	 */
	private String cru;
	/**
	 * A rekord utilsó módosításának dátuma.
	 */
	private Date lmd;
	/**
	 * A rekordot utoljára módosító felhasználó azonosítója.
	 */
	private String lmu;
	/**
	 * A rekord aktív-e?
	 */
	private boolean active;

	public Date getCrd() {
		return this.crd;
	}

	public String getCru() {
		return this.cru;
	}

	public Date getFrom() {
		return this.from;
	}

	public Long getId() {
		return this.id;
	}

	public Date getLmd() {
		return this.lmd;
	}

	public String getLmu() {
		return this.lmu;
	}

	public OwnerDTO getOwner() {
		return this.owner;
	}

	public Date getTo() {
		return this.to;
	}

	public VehicleDTO getVehicle() {
		return this.vehicle;
	}

	public boolean isActive() {
		return this.active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public void setCrd(Date crd) {
		this.crd = crd;
	}

	public void setCru(String cru) {
		this.cru = cru;
	}

	public void setFrom(Date from) {
		this.from = from;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setLmd(Date lmd) {
		this.lmd = lmd;
	}

	public void setLmu(String lmu) {
		this.lmu = lmu;
	}

	public void setOwner(OwnerDTO owner) {
		this.owner = owner;
	}

	public void setTo(Date to) {
		this.to = to;
	}

	public void setVehicle(VehicleDTO vehicle) {
		this.vehicle = vehicle;
	}

}
