package hu.zip.car.data.ui.navigator;

import org.springframework.beans.factory.annotation.Autowired;

import com.vaadin.navigator.View;
import com.vaadin.navigator.ViewChangeListener.ViewChangeEvent;
import com.vaadin.spring.annotation.SpringView;
import com.vaadin.ui.CustomComponent;
import com.vaadin.ui.Grid;
import com.vaadin.ui.renderers.DateRenderer;
import com.vaadin.ui.renderers.NumberRenderer;

import hu.zip.car.data.client.ws.CarDataWSClient;
import hu.zip.car.data.service.dto.VehicleAccessoryDataDTO;
import hu.zip.car.data.service.rest.CarDataServiceEndpoint;
import hu.zip.car.data.ui.MainUI;

@SpringView(name = VehicleAccessoryDataTableView.NAME, ui = MainUI.class)
public class VehicleAccessoryDataTableView extends CustomComponent implements View {
	private static final long serialVersionUID = 1L;
	public final static String NAME = "vehicleAccessoryDataTable";

	@Autowired
	private CarDataWSClient client;

	private Grid<VehicleAccessoryDataDTO> grid;

	@Override
	public void enter(ViewChangeEvent event) {
		this.grid.setItems(this.client.vehicleAccessoryData(null, null, null, null, null));
	}

	private <T> T getValue(T o) {
		return o;
	}

	@Autowired
	public void postConstruct() {
		this.grid = new Grid<>();
		this.grid.setCaption("Gépjármú meta adatok tábla");

		this.grid.addColumn(VehicleAccessoryDataDTO::getId, new NumberRenderer()).setCaption("Azonosító");
		this.grid.addColumn(v -> this.getValue(v.getVehicle().getId()), new NumberRenderer()).setCaption("Gépjármű azonosító");
		this.grid.addColumn(VehicleAccessoryDataDTO::getAccessoryKey).setCaption("Meta adat kúlcs");
		this.grid.addColumn(VehicleAccessoryDataDTO::getAccessoryKeyDenomination).setCaption("Meta adat neve");
		this.grid.addColumn(VehicleAccessoryDataDTO::getAccessoryValue).setCaption("Meta adat értéke");
		this.grid.addColumn(VehicleAccessoryDataDTO::getCru).setCaption("Létrehozó");
		this.grid.addColumn(VehicleAccessoryDataDTO::getCrd, new DateRenderer(CarDataServiceEndpoint.sdfWithoutT)).setCaption("Létrehozás dátuma");
		this.grid.addColumn(VehicleAccessoryDataDTO::getLmu).setCaption("Utólsó módosító");
		this.grid.addColumn(VehicleAccessoryDataDTO::getLmd, new DateRenderer(CarDataServiceEndpoint.sdfWithoutT)).setCaption("Utólsó módosítás dátuma");

		this.setCompositionRoot(this.grid);
		this.grid.setSizeFull();
		this.setSizeFull();
	}

}
