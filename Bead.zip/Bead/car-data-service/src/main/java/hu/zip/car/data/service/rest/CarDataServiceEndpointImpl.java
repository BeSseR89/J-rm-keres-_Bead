package hu.zip.car.data.service.rest;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import hu.zip.car.data.service.dao.OwnerDao;
import hu.zip.car.data.service.dao.VehicleAccessoryDataDao;
import hu.zip.car.data.service.dao.VehicleDao;
import hu.zip.car.data.service.dao.VehicleLifeCycleDao;
import hu.zip.car.data.service.dao.VehicleOwnerXtDao;
import hu.zip.car.data.service.dto.OwnerDTO;
import hu.zip.car.data.service.dto.VehicleAccessoryDataDTO;
import hu.zip.car.data.service.dto.VehicleDTO;
import hu.zip.car.data.service.dto.VehicleLifeCycleDTO;
import hu.zip.car.data.service.dto.VehicleOwnerXtDTO;

@RestController()
@RequestMapping("/api")
public class CarDataServiceEndpointImpl implements CarDataServiceEndpoint {

	@Autowired
	private VehicleDao vehicleDao;

	@Autowired
	private OwnerDao ownerDao;

	@Autowired
	private VehicleLifeCycleDao vehicleLifeCycleDao;

	@Autowired
	private VehicleOwnerXtDao vehicleOwnerXtDao;

	@Autowired
	private VehicleAccessoryDataDao vehicleAccessoryDataDao;

	@Override
	@RequestMapping(path = "")
	public String hello() {
		return "Spring RESTful is started and ready to call.";
	}

	@Override
	@RequestMapping(path = "/tulajdonos", method = RequestMethod.GET, produces = "application/json; charset=UTF-8")
	public List<OwnerDTO> owner(//
			@RequestParam(name = "id", required = false) Long id, //
			@RequestParam(name = "nev", required = false) String name, //
			@RequestParam(name = "lakcim", required = false) String address, //
			@RequestParam(name = "szuletesiDatum", required = false) @DateTimeFormat(pattern = "yyyy-MM-dd'T'hh:mm:ss") Date birtDate, //
			@RequestParam(name = "szuletesiHely", required = false) String birtPlace//
	) {
		return this.ownerDao.findByParams(id, name, address, birtDate, birtPlace);
	}

	@Override
	@RequestMapping(path = "/tulajdonosJarmui", method = RequestMethod.GET, produces = "application/json; charset=UTF-8")
	public List<VehicleDTO> ownerVehicles( //
			@RequestParam(name = "tulajdonosId", required = false) Long ownerId, //
			@RequestParam(name = "tulajdonosNeve", required = false) String ownerName//
	) {
		return this.vehicleDao.findOwnerVehicles(ownerId, ownerName);
	}

	@Override
	@RequestMapping(path = "/jarmu", method = RequestMethod.GET, produces = "application/json; charset=UTF-8")
	public List<VehicleDTO> vehicle(//
			@RequestParam(name = "id", required = false) Long id, //
			@RequestParam(name = "marka", required = false) String brand, //
			@RequestParam(name = "tipus", required = false) String type, //
			@RequestParam(name = "kmallas", required = false) String kilometerPosition, //
			@RequestParam(name = "allapot", required = false) String condition, //
			@RequestParam(name = "kivitel", required = false) String exports, //
			@RequestParam(name = "ar", required = false) Long price//
	) {
		return this.vehicleDao.findByParams(id, brand, type, kilometerPosition, condition, exports, price);
	}

	@Override
	@RequestMapping(path = "/jarmuKiegeszitoData", method = RequestMethod.GET, produces = "application/json; charset=UTF-8")
	public List<VehicleAccessoryDataDTO> vehicleAccessoryData(//
			@RequestParam(name = "id", required = false) Long id, //
			@RequestParam(name = "jarmuId", required = false) Long vehicleId, //
			@RequestParam(name = "kulcs", required = false) String accessoryKey, //
			@RequestParam(name = "kulcsMegnevezes", required = false) String accessoryKeyDenomination, //
			@RequestParam(name = "kulcsErtek", required = false) String accessoryValue//
	) {
		return this.vehicleAccessoryDataDao.findByParams(id, vehicleId, accessoryKey, accessoryKeyDenomination, accessoryValue);
	}

	@Override
	@RequestMapping(path = "/jarmuEletut", method = RequestMethod.GET, produces = "application/json; charset=UTF-8")
	public List<VehicleLifeCycleDTO> vehicleLifeCycle(//
			@RequestParam(name = "id", required = false) Long id, //
			@RequestParam(name = "jarmuId", required = false) Long vehicleId, //
			@RequestParam(name = "esemenyNeve", required = false) String eventName, //
			@RequestParam(name = "esemenyLeirasa", required = false) String eventDescription, //
			@RequestParam(name = "esemenyDatuma", required = false) @DateTimeFormat(pattern = "yyyy-MM-dd'T'hh:mm:ss") Date eventDate//
	) {
		return this.vehicleLifeCycleDao.findByParams(id, vehicleId, eventName, eventDescription, eventDate);
	}

	@Override
	@RequestMapping(path = "xtJarmuTulajdonos", method = RequestMethod.GET, produces = "application/json; charset=UTF-8")
	public List<VehicleOwnerXtDTO> vehicleOwnerXt(//
			@RequestParam(name = "id", required = false) Long id, //
			@RequestParam(name = "jarmuId", required = false) Long vehicleId, //
			@RequestParam(name = "tulajdonosId", required = false) Long ownerId, //
			@RequestParam(name = "mettol", required = false) @DateTimeFormat(pattern = "yyyy-MM-dd'T'hh:mm:ss") Date from, //
			@RequestParam(name = "meddig", required = false) @DateTimeFormat(pattern = "yyyy-MM-dd'T'hh:mm:ss") Date to//
	) {
		return this.vehicleOwnerXtDao.findByParams(id, vehicleId, ownerId, from, to);
	}

}
