package hu.zip.car.data.client.ws;

import hu.zip.car.data.service.rest.CarDataServiceEndpoint;

public interface CarDataWSClient extends CarDataServiceEndpoint {
	//
}
