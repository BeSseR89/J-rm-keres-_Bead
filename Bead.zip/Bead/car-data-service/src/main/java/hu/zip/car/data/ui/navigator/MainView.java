package hu.zip.car.data.ui.navigator;

import org.springframework.beans.factory.annotation.Autowired;

import com.vaadin.navigator.View;
import com.vaadin.navigator.ViewChangeListener.ViewChangeEvent;
import com.vaadin.spring.annotation.SpringView;
import com.vaadin.ui.Alignment;
import com.vaadin.ui.Button;
import com.vaadin.ui.Button.ClickEvent;
import com.vaadin.ui.CustomComponent;
import com.vaadin.ui.Grid;
import com.vaadin.ui.HorizontalLayout;
import com.vaadin.ui.TextField;
import com.vaadin.ui.VerticalLayout;
import com.vaadin.ui.renderers.DateRenderer;
import com.vaadin.ui.renderers.NumberRenderer;

import hu.zip.car.data.client.ws.CarDataWSClient;
import hu.zip.car.data.service.dto.VehicleDTO;
import hu.zip.car.data.service.rest.CarDataServiceEndpoint;
import hu.zip.car.data.ui.MainUI;

@SpringView(name = MainView.NAME, ui = MainUI.class)
public class MainView extends CustomComponent implements View {
	private static final long serialVersionUID = 1L;
	public final static String NAME = "";

	@Autowired
	private CarDataWSClient client;

	private Grid<VehicleDTO> grid;
	private VerticalLayout layout;
	private TextField idTF;
	private TextField brandTF;
	private TextField typeTF;
	private TextField exportTF;
	private TextField conditionTF;
	private TextField kilometerPositionTF;
	private TextField priceTF;

	private void click(ClickEvent e) {
		Long id = this.idTF.getValue().isEmpty() ? null : Long.parseLong(this.idTF.getValue());
		Long price = this.priceTF.getValue().isEmpty() ? null : Long.parseLong(this.priceTF.getValue());
		this.grid.setItems(this.client.vehicle(id, this.brandTF.getValue(), this.typeTF.getValue(), this.kilometerPositionTF.getValue(),
				this.conditionTF.getValue(), this.exportTF.getValue(), price));
	}

	@Override
	public void enter(ViewChangeEvent event) {
		// NOP
	}

	@Autowired
	public void postConstruct() {
		this.layout = new VerticalLayout();
		this.layout.setCaption("Gépjármű keresés");

		this.idTF = new TextField("Gépjármű azonosító");
		this.brandTF = new TextField("Gépjármű márkája");
		this.typeTF = new TextField("Gépjármű típusa");
		this.exportTF = new TextField("Gépjármű kivitelezése");
		this.conditionTF = new TextField("Gépjármű állapota");
		this.kilometerPositionTF = new TextField("Gépjármű kilóméter óra állás");
		this.priceTF = new TextField("Gépjármű ára");

		this.grid = new Grid<>();
		this.grid.setCaption("Keresési eredmény");

		this.grid.addColumn(VehicleDTO::getId, new NumberRenderer()).setCaption("Azonosító");
		this.grid.addColumn(VehicleDTO::getBrand).setCaption("Márka");
		this.grid.addColumn(VehicleDTO::getType).setCaption("Típus");
		this.grid.addColumn(VehicleDTO::getExports).setCaption("Kivitelezés");
		this.grid.addColumn(VehicleDTO::getCondition).setCaption("Állapot");
		this.grid.addColumn(VehicleDTO::getKilometerPosition, new NumberRenderer()).setCaption("Kilóméter óra állás");
		this.grid.addColumn(VehicleDTO::getPrice, new NumberRenderer()).setCaption("Ár");
		this.grid.addColumn(VehicleDTO::getCru).setCaption("Létrehozó");
		this.grid.addColumn(VehicleDTO::getCrd, new DateRenderer(CarDataServiceEndpoint.sdfWithoutT)).setCaption("Létrehozás dátuma");
		this.grid.addColumn(VehicleDTO::getLmu).setCaption("Utólsó módosító");
		this.grid.addColumn(VehicleDTO::getLmd, new DateRenderer(CarDataServiceEndpoint.sdfWithoutT)).setCaption("Utólsó módosítás dátuma");
		this.grid.setSizeFull();

		Button search = new Button("Keresés", e -> this.click(e));

		HorizontalLayout hl1 = new HorizontalLayout(this.idTF, this.brandTF, this.typeTF, this.exportTF);
		hl1.setComponentAlignment(this.idTF, Alignment.TOP_LEFT);
		hl1.setComponentAlignment(this.brandTF, Alignment.TOP_LEFT);
		hl1.setComponentAlignment(this.typeTF, Alignment.TOP_LEFT);
		hl1.setComponentAlignment(this.exportTF, Alignment.TOP_LEFT);

		HorizontalLayout hl2 = new HorizontalLayout(this.conditionTF, this.kilometerPositionTF, this.priceTF);
		hl2.setComponentAlignment(this.conditionTF, Alignment.TOP_LEFT);
		hl2.setComponentAlignment(this.kilometerPositionTF, Alignment.TOP_LEFT);
		hl2.setComponentAlignment(this.priceTF, Alignment.TOP_LEFT);

		HorizontalLayout hl3 = new HorizontalLayout(search);
		hl3.setComponentAlignment(search, Alignment.TOP_LEFT);

		this.layout.addComponent(hl1);
		this.layout.addComponent(hl2);
		this.layout.addComponent(hl3);
		this.layout.addComponent(this.grid);
		this.layout.setComponentAlignment(hl1, Alignment.TOP_LEFT);
		this.layout.setComponentAlignment(hl2, Alignment.TOP_LEFT);
		this.layout.setComponentAlignment(hl3, Alignment.TOP_LEFT);
		this.layout.setComponentAlignment(this.grid, Alignment.TOP_CENTER);
		this.layout.setSizeFull();
		this.setCompositionRoot(this.layout);
	}

}
