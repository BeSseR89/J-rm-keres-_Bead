package hu.zip.car.data.ui.navigator;

import org.springframework.beans.factory.annotation.Autowired;

import com.vaadin.navigator.View;
import com.vaadin.navigator.ViewChangeListener.ViewChangeEvent;
import com.vaadin.spring.annotation.SpringView;
import com.vaadin.ui.CustomComponent;
import com.vaadin.ui.Grid;
import com.vaadin.ui.renderers.DateRenderer;
import com.vaadin.ui.renderers.NumberRenderer;

import hu.zip.car.data.client.ws.CarDataWSClient;
import hu.zip.car.data.service.dto.VehicleOwnerXtDTO;
import hu.zip.car.data.service.rest.CarDataServiceEndpoint;
import hu.zip.car.data.ui.MainUI;

@SpringView(name = VehicleOwnerXtTableView.NAME, ui = MainUI.class)
public class VehicleOwnerXtTableView extends CustomComponent implements View {
	private static final long serialVersionUID = 1L;
	public final static String NAME = "vehicleOwnerXtTable";

	@Autowired
	private CarDataWSClient client;

	private Grid<VehicleOwnerXtDTO> grid;

	@Override
	public void enter(ViewChangeEvent event) {
		this.grid.setItems(this.client.vehicleOwnerXt(null, null, null, null, null));
	}

	private <T> T getValue(T o) {
		return o;
	}

	@Autowired
	public void postConstruct() {
		this.grid = new Grid<>();
		this.grid.setCaption("Tulajdonos-Gépjármű kapcsolati tábla");

		this.grid.addColumn(VehicleOwnerXtDTO::getId, new NumberRenderer()).setCaption("Azonosító");
		this.grid.addColumn(v -> this.getValue(v.getOwner().getName())).setCaption("Személy neve");
		this.grid.addColumn(v -> this.getValue(v.getVehicle().getId()), new NumberRenderer()).setCaption("Gépjármú azonosító");
		this.grid.addColumn(VehicleOwnerXtDTO::getFrom, new DateRenderer(CarDataServiceEndpoint.sdfWithoutT)).setCaption("Mettől");
		this.grid.addColumn(VehicleOwnerXtDTO::getTo, new DateRenderer(CarDataServiceEndpoint.sdfWithoutT)).setCaption("Meddig");
		this.grid.addColumn(VehicleOwnerXtDTO::getCru).setCaption("Létrehozó");
		this.grid.addColumn(VehicleOwnerXtDTO::getCrd, new DateRenderer(CarDataServiceEndpoint.sdfWithoutT)).setCaption("Létrehozás dátuma");
		this.grid.addColumn(VehicleOwnerXtDTO::getLmu).setCaption("Utólsó módosító");
		this.grid.addColumn(VehicleOwnerXtDTO::getLmd, new DateRenderer(CarDataServiceEndpoint.sdfWithoutT)).setCaption("Utólsó módosítás dátuma");

		this.setCompositionRoot(this.grid);
		this.grid.setSizeFull();
		this.setSizeFull();
	}

}
