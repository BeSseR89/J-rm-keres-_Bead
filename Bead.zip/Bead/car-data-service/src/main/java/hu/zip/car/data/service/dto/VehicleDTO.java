package hu.zip.car.data.service.dto;

import java.util.Date;

public class VehicleDTO {

	/**
	 * A tábla egydi azonosítója.
	 */
	private Long id;
	private String brand;
	private String type;
	private Long kilometerPosition;
	private String condition;
	private String exports;
	private Long price;
	/**
	 * Nincs minden esetben kitoltve.
	 */
	private String ownerName;

	/**
	 * A rekord létrehozásának dátuma.
	 */
	private Date crd;

	/**
	 * A rekordot létrehozó felhasználó azonosítója.
	 */
	private String cru;

	/**
	 * A rekord utilsó módosításának dátuma.
	 */
	private Date lmd;
	/**
	 * A rekordot utoljára módosító felhasználó azonosítója.
	 */
	private String lmu;
	/**
	 * A rekord aktív-e?
	 */
	private boolean active;

	public String getBrand() {
		return this.brand;
	}

	public String getCondition() {
		return this.condition;
	}

	public Date getCrd() {
		return this.crd;
	}

	public String getCru() {
		return this.cru;
	}

	public String getExports() {
		return this.exports;
	}

	public Long getId() {
		return this.id;
	}

	public Long getKilometerPosition() {
		return this.kilometerPosition;
	}

	public Date getLmd() {
		return this.lmd;
	}

	public String getLmu() {
		return this.lmu;
	}

	public String getOwnerName() {
		return this.ownerName;
	}

	public Long getPrice() {
		return this.price;
	}

	public String getType() {
		return this.type;
	}

	public boolean isActive() {
		return this.active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public void setCondition(String condition) {
		this.condition = condition;
	}

	public void setCrd(Date crd) {
		this.crd = crd;
	}

	public void setCru(String cru) {
		this.cru = cru;
	}

	public void setExports(String exports) {
		this.exports = exports;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setKilometerPosition(Long kilometerPosition) {
		this.kilometerPosition = kilometerPosition;
	}

	public void setLmd(Date lmd) {
		this.lmd = lmd;
	}

	public void setLmu(String lmu) {
		this.lmu = lmu;
	}

	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}

	public void setPrice(Long price) {
		this.price = price;
	}

	public void setType(String type) {
		this.type = type;
	}

}
