package hu.zip.car.data.ui.navigator;

import org.springframework.beans.factory.annotation.Autowired;

import com.vaadin.navigator.View;
import com.vaadin.navigator.ViewChangeListener.ViewChangeEvent;
import com.vaadin.spring.annotation.SpringView;
import com.vaadin.ui.CustomComponent;
import com.vaadin.ui.Grid;
import com.vaadin.ui.renderers.DateRenderer;
import com.vaadin.ui.renderers.NumberRenderer;

import hu.zip.car.data.client.ws.CarDataWSClient;
import hu.zip.car.data.service.dto.VehicleDTO;
import hu.zip.car.data.service.rest.CarDataServiceEndpoint;
import hu.zip.car.data.ui.MainUI;

@SpringView(name = VehicleTableView.NAME, ui = MainUI.class)
public class VehicleTableView extends CustomComponent implements View {
	private static final long serialVersionUID = 1L;
	public final static String NAME = "vehicleTable";

	@Autowired
	private CarDataWSClient client;

	private Grid<VehicleDTO> grid;

	@Override
	public void enter(ViewChangeEvent event) {
		this.grid.setItems(this.client.vehicle(null, null, null, null, null, null, null));
	}

	@Autowired
	public void postConstruct() {
		this.grid = new Grid<>();
		this.grid.setCaption("Gépjármű tábla");

		this.grid.addColumn(VehicleDTO::getId, new NumberRenderer()).setCaption("Azonosító");
		this.grid.addColumn(VehicleDTO::getBrand).setCaption("Márka");
		this.grid.addColumn(VehicleDTO::getType).setCaption("Típus");
		this.grid.addColumn(VehicleDTO::getExports).setCaption("Kivitelezés");
		this.grid.addColumn(VehicleDTO::getCondition).setCaption("Állapot");
		this.grid.addColumn(VehicleDTO::getKilometerPosition, new NumberRenderer()).setCaption("Kilóméter óra állás");
		this.grid.addColumn(VehicleDTO::getPrice, new NumberRenderer()).setCaption("Ár");
		this.grid.addColumn(VehicleDTO::getCru).setCaption("Létrehozó");
		this.grid.addColumn(VehicleDTO::getCrd, new DateRenderer(CarDataServiceEndpoint.sdfWithoutT)).setCaption("Létrehozás dátuma");
		this.grid.addColumn(VehicleDTO::getLmu).setCaption("Utólsó módosító");
		this.grid.addColumn(VehicleDTO::getLmd, new DateRenderer(CarDataServiceEndpoint.sdfWithoutT)).setCaption("Utólsó módosítás dátuma");

		this.setCompositionRoot(this.grid);
		this.grid.setSizeFull();
		this.setSizeFull();
	}
}
