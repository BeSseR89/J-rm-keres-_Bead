package hu.zip.car.data.service.dto;

import java.io.Serializable;
import java.util.Date;

public class OwnerDTO implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 * A tábla egydi azonosítója.
	 */
	private Long id;
	private String name;
	private String address;
	private Date birtDate;
	private String birtPlace;

	/**
	 * A rekord létrehozásának dátuma.
	 */
	private Date crd;
	/**
	 * A rekordot létrehozó felhasználó azonosítója.
	 */
	private String cru;
	/**
	 * A rekord utilsó módosításának dátuma.
	 */
	private Date lmd;
	/**
	 * A rekordot utoljára módosító felhasználó azonosítója.
	 */
	private String lmu;
	/**
	 * A rekord aktív-e?
	 */
	private boolean active;

	public String getAddress() {
		return this.address;
	}

	public Date getBirtDate() {
		return this.birtDate;
	}

	public String getBirtPlace() {
		return this.birtPlace;
	}

	public Date getCrd() {
		return this.crd;
	}

	public String getCru() {
		return this.cru;
	}

	public Long getId() {
		return this.id;
	}

	public Date getLmd() {
		return this.lmd;
	}

	public String getLmu() {
		return this.lmu;
	}

	public String getName() {
		return this.name;
	}

	public boolean isActive() {
		return this.active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public void setBirtDate(Date birtDate) {
		this.birtDate = birtDate;
	}

	public void setBirtPlace(String birtPlace) {
		this.birtPlace = birtPlace;
	}

	public void setCrd(Date crd) {
		this.crd = crd;
	}

	public void setCru(String cru) {
		this.cru = cru;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setLmd(Date lmd) {
		this.lmd = lmd;
	}

	public void setLmu(String lmu) {
		this.lmu = lmu;
	}

	public void setName(String name) {
		this.name = name;
	}
}
