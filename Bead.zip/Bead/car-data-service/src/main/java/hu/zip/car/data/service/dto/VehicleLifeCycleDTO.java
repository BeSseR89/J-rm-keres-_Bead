package hu.zip.car.data.service.dto;

import java.util.Date;

public class VehicleLifeCycleDTO {

	/**
	 * A tábla egydi azonosítója.
	 */
	private Long id;
	private VehicleDTO vehicle;
	private String eventName;
	private String eventDescription;
	private Date eventDate;

	/**
	 * A rekord létrehozásának dátuma.
	 */
	private Date crd;
	/**
	 * A rekordot létrehozó felhasználó azonosítója.
	 */
	private String cru;
	/**
	 * A rekord utilsó módosításának dátuma.
	 */
	private Date lmd;
	/**
	 * A rekordot utoljára módosító felhasználó azonosítója.
	 */
	private String lmu;
	/**
	 * A rekord aktív-e?
	 */
	private boolean active;

	public Date getCrd() {
		return this.crd;
	}

	public String getCru() {
		return this.cru;
	}

	public Date getEventDate() {
		return this.eventDate;
	}

	public String getEventDescription() {
		return this.eventDescription;
	}

	public String getEventName() {
		return this.eventName;
	}

	public Long getId() {
		return this.id;
	}

	public Date getLmd() {
		return this.lmd;
	}

	public String getLmu() {
		return this.lmu;
	}

	public VehicleDTO getVehicle() {
		return this.vehicle;
	}

	public boolean isActive() {
		return this.active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public void setCrd(Date crd) {
		this.crd = crd;
	}

	public void setCru(String cru) {
		this.cru = cru;
	}

	public void setEventDate(Date eventDate) {
		this.eventDate = eventDate;
	}

	public void setEventDescription(String eventDescription) {
		this.eventDescription = eventDescription;
	}

	public void setEventName(String eventName) {
		this.eventName = eventName;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setLmd(Date lmd) {
		this.lmd = lmd;
	}

	public void setLmu(String lmu) {
		this.lmu = lmu;
	}

	public void setVehicle(VehicleDTO vehicle) {
		this.vehicle = vehicle;
	}

}
