package hu.zip.car.data.service.rest;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import hu.zip.car.data.service.dao.OwnerDao;
import hu.zip.car.data.service.dao.VehicleAccessoryDataDao;
import hu.zip.car.data.service.dao.VehicleDao;
import hu.zip.car.data.service.dao.VehicleLifeCycleDao;
import hu.zip.car.data.service.dao.VehicleOwnerXtDao;
import hu.zip.car.data.service.dto.OwnerDTO;
import hu.zip.car.data.service.dto.VehicleAccessoryDataDTO;
import hu.zip.car.data.service.dto.VehicleDTO;
import hu.zip.car.data.service.dto.VehicleLifeCycleDTO;
import hu.zip.car.data.service.dto.VehicleOwnerXtDTO;

public interface CarDataServiceEndpoint {

	final SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'hh:mm:ss");
	final SimpleDateFormat sdfWithoutT = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");

	public String hello();

	/**
	 * @see OwnerDao#findByParams(java.lang.Long, java.lang.String,
	 *      java.lang.String, java.util.Date, java.lang.String)
	 * @param id
	 * @param name
	 * @param address
	 * @param birtDate
	 * @param birtPlace
	 * @return
	 */
	public List<OwnerDTO> owner(Long id, String name, String address, Date birtDate, String birtPlace);

	/**
	 * @see VehicleDao#findOwnerVehicles(java.lang.Long, java.lang.String)
	 * @param ownerId
	 * @param ownerName
	 * @return
	 */
	public List<VehicleDTO> ownerVehicles(Long ownerId, String ownerName);

	/**
	 * @see VehicleDao#findByParams(java.lang.Long, java.lang.String,
	 *      java.lang.String, java.lang.String, java.lang.String,
	 *      java.lang.String, java.lang.Long)
	 * @param id
	 * @param brand
	 * @param type
	 * @param kilometerPosition
	 * @param condition
	 * @param exports
	 * @param price
	 * @return
	 */
	public List<VehicleDTO> vehicle(Long id, String brand, String type, String kilometerPosition, String condition, String exports, Long price);

	/**
	 * @see VehicleAccessoryDataDao#findByParams(java.lang.Long, java.lang.Long,
	 *      java.lang.String, java.lang.String, java.lang.String)
	 * @param id
	 * @param vehicleId
	 * @param accessoryKey
	 * @param accessoryKeyDenomination
	 * @param accessoryValue
	 * @return
	 */
	public List<VehicleAccessoryDataDTO> vehicleAccessoryData(Long id, Long vehicleId, String accessoryKey, String accessoryKeyDenomination,
			String accessoryValue);

	/**
	 * @see VehicleLifeCycleDao#findByParams(java.lang.Long, java.lang.Long,
	 *      java.lang.String, java.lang.String, java.util.Date)
	 * @param id
	 * @param vehicleId
	 * @param eventName
	 * @param eventDescription
	 * @param eventDate
	 * @return
	 */
	public List<VehicleLifeCycleDTO> vehicleLifeCycle(Long id, Long vehicleId, String eventName, String eventDescription, Date eventDate);

	/**
	 * @see VehicleOwnerXtDao#findByParams(java.lang.Long, java.lang.Long,
	 *      java.lang.Long, java.util.Date, java.util.Date)
	 * @param id
	 * @param vehicleId
	 * @param ownerId
	 * @param from
	 * @param to
	 * @return
	 */
	public List<VehicleOwnerXtDTO> vehicleOwnerXt(Long id, Long vehicleId, Long ownerId, Date from, Date to);

}
