package hu.zip.car.data.ui.navigator;

import org.springframework.beans.factory.annotation.Autowired;

import com.vaadin.navigator.View;
import com.vaadin.navigator.ViewChangeListener.ViewChangeEvent;
import com.vaadin.spring.annotation.SpringView;
import com.vaadin.ui.CustomComponent;
import com.vaadin.ui.Grid;
import com.vaadin.ui.renderers.DateRenderer;
import com.vaadin.ui.renderers.NumberRenderer;

import hu.zip.car.data.client.ws.CarDataWSClient;
import hu.zip.car.data.service.dto.VehicleLifeCycleDTO;
import hu.zip.car.data.service.rest.CarDataServiceEndpoint;
import hu.zip.car.data.ui.MainUI;

@SpringView(name = VehicleLifeCycleTableView.NAME, ui = MainUI.class)
public class VehicleLifeCycleTableView extends CustomComponent implements View {
	private static final long serialVersionUID = 1L;
	public final static String NAME = "vehicleLifeCycleTable";

	@Autowired
	private CarDataWSClient client;

	private Grid<VehicleLifeCycleDTO> grid;

	@Override
	public void enter(ViewChangeEvent event) {
		this.grid.setItems(this.client.vehicleLifeCycle(null, null, null, null, null));
	}

	private <T> T getValue(T o) {
		return o;
	}

	@Autowired
	public void postConstruct() {
		this.grid = new Grid<>();
		this.grid.setCaption("Gépjármű élet út tábla");

		this.grid.addColumn(VehicleLifeCycleDTO::getId, new NumberRenderer()).setCaption("Azonosító");
		this.grid.addColumn(v -> this.getValue(v.getVehicle().getId()), new NumberRenderer()).setCaption("Gépjármű azonosító");
		this.grid.addColumn(VehicleLifeCycleDTO::getEventName).setCaption("Esemény neve");
		this.grid.addColumn(VehicleLifeCycleDTO::getEventDescription).setCaption("Esemény leírása");
		this.grid.addColumn(VehicleLifeCycleDTO::getEventDate, new DateRenderer(CarDataServiceEndpoint.sdfWithoutT)).setCaption("Esemény dátuma");
		this.grid.addColumn(VehicleLifeCycleDTO::getCru).setCaption("Létrehozó");
		this.grid.addColumn(VehicleLifeCycleDTO::getCrd, new DateRenderer(CarDataServiceEndpoint.sdfWithoutT)).setCaption("Létrehozás dátuma");
		this.grid.addColumn(VehicleLifeCycleDTO::getLmu).setCaption("Utólsó módosító");
		this.grid.addColumn(VehicleLifeCycleDTO::getLmd, new DateRenderer(CarDataServiceEndpoint.sdfWithoutT)).setCaption("Utólsó módosítás dátuma");

		this.setCompositionRoot(this.grid);
		this.grid.setSizeFull();
		this.setSizeFull();
	}
}
