package hu.zip.car.data.service.config;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class DataBaseConfig {

	/**
	 * pelda kapcsolat:
	 * jdbc:mysql://[dbhost]:[dbport]/[dbname]?serverTimezone=UTC&useSSL=false
	 *
	 * A serverTimezone=UTC&useSSL=false fontos mivel a MYSQL connector bugos
	 * 5.1.x verziotol folfele. Es mivel a legujabb MYSQL szervert hasznaltam
	 * neki kellet az uj connector mar ami most a 6.0.3 lett neki beallitva.
	 *
	 * @throws SQLException
	 *             Nem lehet kapcsolatot epiteni a MYSQL szerverrel.
	 * @return DB kapcsolat.
	 */
	@Bean(name = "mysqlConncetion")
	public Connection mysqlConncetion() throws SQLException {
		return DriverManager.getConnection("jdbc:mysql://localhost:3306/caruser?serverTimezone=UTC&useSSL=false", "root", "root");
	}

}
