package hu.zip.car.data.util;

public final class StringUtils {

    private StringUtils() {
        // NOP
    }

    public static final String trimToNull(String s) {
        if (s == null || s.trim().isEmpty()) {
            return null;
        }
        return s.trim();
    }

}
