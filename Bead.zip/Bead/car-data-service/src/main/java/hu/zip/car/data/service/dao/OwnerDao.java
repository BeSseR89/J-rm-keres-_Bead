package hu.zip.car.data.service.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import hu.zip.car.data.service.dto.OwnerDTO;
import hu.zip.car.data.util.StringUtils;

@Service
public class OwnerDao {

    private static final Logger LOG = LoggerFactory.getLogger(VehicleDao.class);
    private static final SimpleDateFormat SDF = new SimpleDateFormat("yyyy-MM-dd");

    public static final String TABLE_NAME = "TULAJDONOS";
    public static final String COLUMN_ID = "ID";
    public static final String COLUMN_NAME = "NEV";
    public static final String COLUMN_ADDRESS = "LAKCIM";
    public static final String COLUMN_BIRTDATE = "SZULETESI_DATUM";
    public static final String COLUMN_BIRTPLACE = "SZULETESI_HELY";
    public static final String COLUMN_CRD = "CRD";
    public static final String COLUMN_CRU = "CRU";
    public static final String COLUMN_LMD = "LMD";
    public static final String COLUMN_LMU = "LMU";
    public static final String COLUMN_ACTIVE = "AKTIV";

    @Qualifier("mysqlConncetion")
    @Autowired
    private Connection con;

    /**
     * A megdot feltetelek allapjan keres a TULAJDONOS tablaban.
     *
     * @param id Tabla azonosito.
     * @param name Tulajdonos neve.
     * @param address Tulajdonos cime.
     * @param birtDate Tulajdonos szuletesi datuma.
     * @param birtPlace Tulajdonos szuletesi helye.
     * @return Egy Tulajdonos lista ami megfelelt a keresesi felteteleknek.
     */
    public List<OwnerDTO> findByParams(Long id, String name, String address, Date birtDate, String birtPlace) {
        Statement statement = null;
        try {
            statement = this.con.createStatement();
            StringBuilder sb = new StringBuilder();
            sb.append("SELECT * FROM ").append(TABLE_NAME);

            if (Objects.nonNull(id) || Objects.nonNull(StringUtils.trimToNull(name))//
                    || Objects.nonNull(StringUtils.trimToNull(address))//
                    || Objects.nonNull(birtDate)//
                    || Objects.nonNull(StringUtils.trimToNull(birtPlace))//
                    ) {
                sb.append(" WHERE ");
            }
            if (Objects.nonNull(id)) {
                sb.append(COLUMN_ID).append("=").append(id);
                sb.append(" AND ");
            }
            if (Objects.nonNull(StringUtils.trimToNull(name))) {
                sb.append(COLUMN_NAME).append(" LIKE \"%").append(name).append("%\"");
                sb.append(" AND ");
            }
            if (Objects.nonNull(StringUtils.trimToNull(address))) {
                sb.append(COLUMN_ADDRESS).append(" LIKE \"%").append(address).append("%\"");
                sb.append(" AND ");
            }
            if (Objects.nonNull(birtDate)) {
                sb.append(COLUMN_BIRTDATE).append(" BETWEEN \"")//
                        .append(SDF.format(birtDate)).append("\" DATE(CURRENT_DATE)");
                sb.append(" AND ");
            }
            if (Objects.nonNull(StringUtils.trimToNull(birtPlace))) {
                sb.append(COLUMN_BIRTPLACE).append(" LIKE \"%").append(birtPlace).append("%\"");
            }

            String sql = sb.toString();
            if (sql.endsWith(" AND ")) {
                sql = sql.substring(0, sql.length() - 5);
            }
            LOG.info("SQL command: {}", sql);
            ResultSet resultSet = statement.executeQuery(sql);
            List<OwnerDTO> resultList = new ArrayList<>();
            while (resultSet.next()) {
                OwnerDTO dto = new OwnerDTO();

                dto.setId(resultSet.getLong(COLUMN_ID));
                dto.setName(resultSet.getString(COLUMN_NAME));
                dto.setAddress(resultSet.getString(COLUMN_ADDRESS));
                dto.setBirtDate(resultSet.getDate(COLUMN_BIRTDATE));
                dto.setBirtPlace(resultSet.getString(COLUMN_BIRTPLACE));
                dto.setCrd(resultSet.getDate(COLUMN_CRD));
                dto.setCru(resultSet.getString(COLUMN_CRU));
                dto.setLmd(resultSet.getDate(COLUMN_LMD));
                dto.setLmu(resultSet.getString(COLUMN_LMU));
                dto.setActive(resultSet.getBoolean(COLUMN_ACTIVE));

                resultList.add(dto);
            }
            return resultList;
        } catch (SQLException e) {
            LOG.error(e.getMessage(), e);

        } finally {
            if (statement != null) {
                try {
                    statement.close();
                } catch (SQLException e) {
                    LOG.error(e.getMessage(), e);
                }
            }
        }
        return null;
    }

    /**
     *
     * @param id Tabla azonosito
     * @return Egy tulajdonost add vissza.
     */
    OwnerDTO findOne(long id) {
        List<OwnerDTO> result = findByParams(id, null, null, null, null);
        return (result.isEmpty()) ? null : result.get(0);
    }

}
