package hu.zip.car.data.service.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import hu.zip.car.data.service.dto.VehicleDTO;
import hu.zip.car.data.util.StringUtils;

@Service
public class VehicleDao {

    private static final Logger LOG = LoggerFactory.getLogger(VehicleDao.class);
    public static final String TABLE_NAME = "JARMU";
    public static final String COLUMN_ID = "ID";
    public static final String COLUMN_BRAND = "MARKA";
    public static final String COLUMN_TYPE = "TÍPUS";
    public static final String COLUMN_KILOMETER_POSITION = "KM_ALLAS";
    public static final String COLUMN_CONDITION = "ALLAPOT";
    public static final String COLUMN_EXPORTS = "KIVITEL";
    public static final String COLUMN_PRICE = "AR";
    public static final String COLUMN_CRD = "CRD";
    public static final String COLUMN_CRU = "CRU";
    public static final String COLUMN_LMD = "LMD";
    public static final String COLUMN_LMU = "LMU";
    public static final String COLUMN_ACTIVE = "AKTIV";

    @Qualifier("mysqlConncetion")
    @Autowired
    private Connection con;

    /**
     * Keres a JARMU tablaban a megadott parameterekkel.
     *
     * @param id Jarmu tabla azonosito.
     * @param brand Jarmu markaja
     * @param type Jarmu tipusa.
     * @param kilometerPosition Jarmu kilometer ora allasa.
     * @param condition Jarmu alapota.
     * @param exports Jarmu kivitele.
     * @param price Jarmu ara.
     * @return Egy list a keresesi felteteleknek megfelelo jarmuvekbol.
     */
    public List<VehicleDTO> findByParams(Long id, String brand, String type, String kilometerPosition, String condition, String exports, Long price) {
        Statement statement = null;
        try {
            statement = this.con.createStatement();
            StringBuilder sb = new StringBuilder();
            sb.append("SELECT * FROM ").append(TABLE_NAME);

            if (Objects.nonNull(id) || Objects.nonNull(StringUtils.trimToNull(brand))//
                    || Objects.nonNull(StringUtils.trimToNull(type))//
                    || Objects.nonNull(StringUtils.trimToNull(kilometerPosition))//
                    || Objects.nonNull(StringUtils.trimToNull(condition))//
                    || Objects.nonNull(StringUtils.trimToNull(exports))//
                    || Objects.nonNull(price)//
                    ) {
                sb.append(" WHERE ");
            }
            if (Objects.nonNull(id)) {
                sb.append(COLUMN_ID).append("=").append(id);
                sb.append(" AND ");
            }
            if (Objects.nonNull(StringUtils.trimToNull(brand))) {
                sb.append(COLUMN_BRAND).append(" LIKE \"%").append(brand).append("%\"");
                sb.append(" AND ");
            }
            if (Objects.nonNull(StringUtils.trimToNull(type))) {
                sb.append(COLUMN_TYPE).append(" LIKE \"%").append(type).append("%\"");
                sb.append(" AND ");
            }
            if (Objects.nonNull(StringUtils.trimToNull(kilometerPosition))) {
                sb.append(COLUMN_KILOMETER_POSITION).append(">=").append(kilometerPosition);
                sb.append(" AND ");
            }
            if (Objects.nonNull(StringUtils.trimToNull(condition))) {
                sb.append(COLUMN_CONDITION).append(" LIKE \"%").append(condition).append("%\"");
                sb.append(" AND ");
            }
            if (Objects.nonNull(StringUtils.trimToNull(exports))) {
                sb.append(COLUMN_EXPORTS).append(" LIKE \"%").append(exports).append("%\"");
                sb.append(" AND ");
            }
            if (Objects.nonNull(price)) {
                sb.append(COLUMN_PRICE).append(">=").append(price);
            }

            String sql = sb.toString();
            if (sql.endsWith(" AND ")) {
                sql = sql.substring(0, sql.length() - 5);
            }
            LOG.info("SQL command: {}", sql);
            ResultSet resultSet = statement.executeQuery(sql);
            List<VehicleDTO> resultList = new ArrayList<>();
            while (resultSet.next()) {
                VehicleDTO dto = new VehicleDTO();

                dto.setId(resultSet.getLong(COLUMN_ID));
                dto.setBrand(resultSet.getString(COLUMN_BRAND));
                dto.setType(resultSet.getString(COLUMN_TYPE));
                dto.setKilometerPosition(resultSet.getLong(COLUMN_KILOMETER_POSITION));
                dto.setCondition(resultSet.getString(COLUMN_CONDITION));
                dto.setExports(resultSet.getString(COLUMN_EXPORTS));
                dto.setPrice(resultSet.getLong(COLUMN_PRICE));
                dto.setCrd(resultSet.getDate(COLUMN_CRD));
                dto.setCru(resultSet.getString(COLUMN_CRU));
                dto.setLmd(resultSet.getDate(COLUMN_LMD));
                dto.setLmu(resultSet.getString(COLUMN_LMU));
                dto.setActive(resultSet.getBoolean(COLUMN_ACTIVE));

                resultList.add(dto);
            }
            return resultList;
        } catch (SQLException e) {
            LOG.error(e.getMessage(), e);

        } finally {
            if (statement != null) {
                try {
                    statement.close();
                } catch (SQLException e) {
                    LOG.error(e.getMessage(), e);
                }
            }
        }
        return null;
    }

    /**
     * Vissza add egy JARMU-vet a tabla azonosito altal.
     *
     * @param id JARMU tabla azonosito.
     * @return Egy JARMU.
     */
    VehicleDTO findOne(long id) {
        List<VehicleDTO> result = findByParams(id, null, null, null, null, null, null);
        return (result.isEmpty()) ? null : result.get(0);
    }

    /**
     * A tulajdonoshoz tarozo jarmuveket lehet lekerni.
     *
     * @param ownerId Tulajdonos tabla azonositoja.
     * @param ownerName Tulajdonos neve. (reszlete)
     * @return A tulajdonoshoz tartozo jarmuvek.
     */
    public List<VehicleDTO> findOwnerVehicles(Long ownerId, String ownerName) {
        Statement statement = null;
        if (Objects.isNull(ownerId) && Objects.isNull(ownerName)) {
            return Collections.emptyList();
        }
        try {
            String vehicalJoinKey = "v";
            String ownerJoinKey = "ow";
            String ownerVehicalXtJoinKey = "ojxt";

            statement = this.con.createStatement();
            StringBuilder sb = new StringBuilder();
            sb.append("SELECT ").append(vehicalJoinKey).append(".*")//
                    .append(", ").append(ownerJoinKey).append(".*")//
                    .append(" FROM ").append(TABLE_NAME).append(" ").append(vehicalJoinKey)//
                    //-------------------------------------------------------------------------------------
                    .append(" LEFT JOIN ").append(VehicleOwnerXtDao.TABLE_NAME)//
                    .append(" ").append(ownerVehicalXtJoinKey).append(" ON ")//
                    .append(vehicalJoinKey).append(".").append(COLUMN_ID).append(" = ")//
                    .append(ownerVehicalXtJoinKey).append(".").append(VehicleOwnerXtDao.COLUMN_VEHICLE)//
                    //-------------------------------------------------------------------------------------
                    .append(" LEFT JOIN ").append(OwnerDao.TABLE_NAME)//
                    .append(" ").append(ownerJoinKey).append(" ON ")//
                    .append(ownerVehicalXtJoinKey).append(".").append(VehicleOwnerXtDao.COLUMN_OWNER).append(" = ")//
                    .append(ownerJoinKey).append(".").append(OwnerDao.COLUMN_ID)//
                    .append(" WHERE ");

            if (Objects.nonNull(StringUtils.trimToNull(ownerName))) {
                sb.append(ownerJoinKey).append(".").append(OwnerDao.COLUMN_NAME)//
                        .append(" LIKE \"%").append(ownerName).append("%\"");
            } else if (Objects.nonNull(ownerId)) {
                sb.append(ownerJoinKey).append(".").append(OwnerDao.COLUMN_ID)//
                        .append("=").append(ownerId);
            }

            LOG.info("SQL command: {}", sb.toString());
            ResultSet resultSet = statement.executeQuery(sb.toString());
            List<VehicleDTO> resultList = new ArrayList<>();
            while (resultSet.next()) {
                VehicleDTO dto = new VehicleDTO();

                dto.setId(resultSet.getLong(COLUMN_ID));
                dto.setBrand(resultSet.getString(COLUMN_BRAND));
                dto.setType(resultSet.getString(COLUMN_TYPE));
                dto.setKilometerPosition(resultSet.getLong(COLUMN_KILOMETER_POSITION));
                dto.setCondition(resultSet.getString(COLUMN_CONDITION));
                dto.setExports(resultSet.getString(COLUMN_EXPORTS));
                dto.setPrice(resultSet.getLong(COLUMN_PRICE));
                dto.setOwnerName(resultSet.getString(OwnerDao.COLUMN_NAME));
                dto.setCrd(resultSet.getDate(COLUMN_CRD));
                dto.setCru(resultSet.getString(COLUMN_CRU));
                dto.setLmd(resultSet.getDate(COLUMN_LMD));
                dto.setLmu(resultSet.getString(COLUMN_LMU));
                dto.setActive(resultSet.getBoolean(COLUMN_ACTIVE));

                resultList.add(dto);
            }
            return resultList;
        } catch (SQLException e) {
            LOG.error(e.getMessage(), e);

        } finally {
            if (statement != null) {
                try {
                    statement.close();
                } catch (SQLException e) {
                    LOG.error(e.getMessage(), e);
                }
            }
        }
        return null;
    }

}
