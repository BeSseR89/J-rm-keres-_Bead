package hu.zip.car.data.ui;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;

import com.vaadin.annotations.Theme;
import com.vaadin.event.MouseEvents;
import com.vaadin.server.VaadinRequest;
import com.vaadin.shared.ui.ContentMode;
import com.vaadin.spring.annotation.SpringUI;
import com.vaadin.spring.navigator.SpringNavigator;
import com.vaadin.ui.Button;
import com.vaadin.ui.ComponentContainer;
import com.vaadin.ui.CssLayout;
import com.vaadin.ui.Label;
import com.vaadin.ui.UI;
import com.vaadin.ui.themes.ValoTheme;

import hu.zip.car.data.ui.component.MenuLayout;
import hu.zip.car.data.ui.navigator.MainView;
import hu.zip.car.data.ui.navigator.OwnerTableView;
import hu.zip.car.data.ui.navigator.VehicleAccessoryDataTableView;
import hu.zip.car.data.ui.navigator.VehicleLifeCycleTableView;
import hu.zip.car.data.ui.navigator.VehicleOwnerXtTableView;
import hu.zip.car.data.ui.navigator.VehicleTableView;

@SpringUI(path = "/main")
@Theme(ValoTheme.THEME_NAME)
public class MainUI extends UI {
	private static final long serialVersionUID = 1L;

	private SpringNavigator navigator;

	@Autowired
	private ApplicationContext appCtx;

	private final MenuLayout root = new MenuLayout();
	private final ComponentContainer viewDisplay = this.root.getContentContainer();
	private final CssLayout menu = new CssLayout();
	private final CssLayout menuItemsLayout = new CssLayout();

	private com.vaadin.ui.Component buildMenu() {

		Button searchButton = new Button("Keresés", e -> this.navigator.navigateTo(MainView.NAME));
		Button ownerTableButton = new Button("Tulajdonos tábla", e -> this.navigator.navigateTo(OwnerTableView.NAME));
		Button vehicleAccessoryDataTableButton = new Button("Jármü túlajdonságai tábla", e -> this.navigator.navigateTo(VehicleAccessoryDataTableView.NAME));
		Button vehicleLifeCycleTableButton = new Button("Jármü életút tábla", e -> this.navigator.navigateTo(VehicleLifeCycleTableView.NAME));
		Button vehicleOwnerXtTableButton = new Button("Jármü-Tulajdonos kapcsolat", e -> this.navigator.navigateTo(VehicleOwnerXtTableView.NAME));
		Button vehicleTableButton = new Button("Jármü tábla", e -> this.navigator.navigateTo(VehicleTableView.NAME));

		searchButton.setPrimaryStyleName(ValoTheme.MENU_ITEM);
		ownerTableButton.setPrimaryStyleName(ValoTheme.MENU_ITEM);
		vehicleAccessoryDataTableButton.setPrimaryStyleName(ValoTheme.MENU_ITEM);
		vehicleLifeCycleTableButton.setPrimaryStyleName(ValoTheme.MENU_ITEM);
		vehicleOwnerXtTableButton.setPrimaryStyleName(ValoTheme.MENU_ITEM);
		vehicleTableButton.setPrimaryStyleName(ValoTheme.MENU_ITEM);

		this.menuItemsLayout.addComponent(searchButton);
		this.menuItemsLayout.addComponent(ownerTableButton);
		this.menuItemsLayout.addComponent(vehicleAccessoryDataTableButton);
		this.menuItemsLayout.addComponent(vehicleLifeCycleTableButton);
		this.menuItemsLayout.addComponent(vehicleOwnerXtTableButton);
		this.menuItemsLayout.addComponent(vehicleTableButton);

		Label labelMenu = new Label("<div width=\"100%\"><b>Menü</b></div>", ContentMode.HTML);
		labelMenu.setWidth("100%");
		labelMenu.setPrimaryStyleName("valo-menuitems");
		this.menu.addComponent(labelMenu);

		this.menuItemsLayout.setPrimaryStyleName("valo-menuitems");
		this.menu.addComponent(this.menuItemsLayout);

		return this.menu;
	}

	@Override
	protected void init(VaadinRequest request) {

		this.root.addMenu(this.buildMenu());

		this.setContent(this.root);
		this.addStyleName(ValoTheme.UI_WITH_MENU);

		this.setSizeFull();

		this.navigator = new SpringNavigator();
		this.appCtx.getAutowireCapableBeanFactory().autowireBean(this.navigator);
		this.navigator.init(this, this.viewDisplay);
		this.navigator.navigateTo(MainView.NAME);

		this.addClickListener(new MouseEvents.ClickListener() {
			private static final long serialVersionUID = 1L;

			@Override
			public void click(com.vaadin.event.MouseEvents.ClickEvent event) {
				// Letiltja a jobbclickes context menüt.
			}
		});
	}

}
