package hu.zip.car.data.ui.navigator;

import org.springframework.beans.factory.annotation.Autowired;

import com.vaadin.navigator.View;
import com.vaadin.navigator.ViewChangeListener.ViewChangeEvent;
import com.vaadin.spring.annotation.SpringView;
import com.vaadin.ui.CustomComponent;
import com.vaadin.ui.Grid;
import com.vaadin.ui.renderers.DateRenderer;
import com.vaadin.ui.renderers.NumberRenderer;

import hu.zip.car.data.client.ws.CarDataWSClient;
import hu.zip.car.data.service.dto.OwnerDTO;
import hu.zip.car.data.service.rest.CarDataServiceEndpoint;
import hu.zip.car.data.ui.MainUI;

@SpringView(name = OwnerTableView.NAME, ui = MainUI.class)
public class OwnerTableView extends CustomComponent implements View {
	private static final long serialVersionUID = 1L;
	public final static String NAME = "ownerTable";

	@Autowired
	private CarDataWSClient client;

	private Grid<OwnerDTO> grid;

	@Override
	public void enter(ViewChangeEvent event) {
		this.grid.setItems(this.client.owner(null, null, null, null, null));
	}

	@Autowired
	public void postConstruct() {
		this.grid = new Grid<>();
		this.grid.setCaption("Tulajdonosok tábla");

		this.grid.addColumn(OwnerDTO::getId, new NumberRenderer()).setCaption("Azonosító");
		this.grid.addColumn(OwnerDTO::getName).setCaption("Név");
		this.grid.addColumn(OwnerDTO::getBirtDate, new DateRenderer(CarDataServiceEndpoint.sdfWithoutT)).setCaption("Születési dátum");
		this.grid.addColumn(OwnerDTO::getBirtPlace).setCaption("Születési hely");
		this.grid.addColumn(OwnerDTO::getAddress).setCaption("Cím");
		this.grid.addColumn(OwnerDTO::getCru).setCaption("Létrehozó");
		this.grid.addColumn(OwnerDTO::getCrd, new DateRenderer(CarDataServiceEndpoint.sdfWithoutT)).setCaption("Létrehozás dátuma");
		this.grid.addColumn(OwnerDTO::getLmu).setCaption("Utólsó módosító");
		this.grid.addColumn(OwnerDTO::getLmd, new DateRenderer(CarDataServiceEndpoint.sdfWithoutT)).setCaption("Utólsó módosítás dátuma");

		this.setCompositionRoot(this.grid);
		this.grid.setSizeFull();
		this.setSizeFull();
	}
}
