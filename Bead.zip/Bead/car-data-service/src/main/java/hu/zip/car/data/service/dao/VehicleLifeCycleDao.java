package hu.zip.car.data.service.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import hu.zip.car.data.service.dto.VehicleLifeCycleDTO;
import hu.zip.car.data.util.StringUtils;

@Service
public class VehicleLifeCycleDao {

    private static final Logger LOG = LoggerFactory.getLogger(VehicleDao.class);
    private static final SimpleDateFormat SDF = new SimpleDateFormat("yyyy-MM-dd");

    public static final String TABLE_NAME = "JARMU_ELETUT";
    public static final String COLUMN_ID = "ID";
    public static final String COLUMN_VEHICLE = "JARMU_ID";
    public static final String COLUMN_EVENT_NAME = "ESEMENY_NEVE";
    public static final String COLUMN_EVENT_DESCRIPTION = "ESEMENY_LEIRAS";
    public static final String COLUMN_EVENT_DATE = "ESEMENY_DATUMA";
    public static final String COLUMN_CRD = "CRD";
    public static final String COLUMN_CRU = "CRU";
    public static final String COLUMN_LMD = "LMD";
    public static final String COLUMN_LMU = "LMU";
    public static final String COLUMN_ACTIVE = "AKTIV";

    @Qualifier("mysqlConncetion")
    @Autowired
    private Connection con;

    @Autowired
    private VehicleDao vehicleDao;

    /**
     *
     * @param id Tabla azonosito.
     * @param vehicleId JARMU azonosito.
     * @param eventName Esemeny neve.
     * @param eventDescription Esemeny leirasa.
     * @param eventDate Esemeny datuma.
     * @return A megadot felteteleknek megfelelo JARMU eletutjanak adatai.
     */
    public List<VehicleLifeCycleDTO> findByParams(Long id, Long vehicleId, String eventName, String eventDescription, Date eventDate) {
        Statement statement = null;
        try {
            statement = this.con.createStatement();
            StringBuilder sb = new StringBuilder();
            sb.append("SELECT * FROM ").append(TABLE_NAME);

            if (Objects.nonNull(id) || Objects.nonNull(vehicleId)//
                    || Objects.nonNull(StringUtils.trimToNull(eventName))//
                    || Objects.nonNull(StringUtils.trimToNull(eventDescription))// 
                    || Objects.nonNull(eventDate)//
                    ) {
                sb.append(" WHERE ");
            }
            if (Objects.nonNull(id)) {
                sb.append(COLUMN_ID).append("=").append(id);
                sb.append(" AND ");
            }
            if (Objects.nonNull(vehicleId)) {
                sb.append(COLUMN_VEHICLE).append("=").append(vehicleId);
                sb.append(" AND ");
            }
            if (Objects.nonNull(StringUtils.trimToNull(eventName))) {
                sb.append(COLUMN_EVENT_NAME).append(" LIKE \"%").append(eventName).append("%\"");
                sb.append(" AND ");
            }
            if (Objects.nonNull(StringUtils.trimToNull(eventDescription))) {
                sb.append(COLUMN_EVENT_DESCRIPTION).append(" LIKE \"%").append(eventDescription).append("%\"");
                sb.append(" AND ");
            }
            if (Objects.nonNull(eventDate)) {
                sb.append(COLUMN_EVENT_DATE).append(" BETWEEN \"")//
                        .append(SDF.format(eventDate)).append("\" DATE(CURRENT_DATE)");
            }

            String sql = sb.toString();
            if (sql.endsWith(" AND ")) {
                sql = sql.substring(0, sql.length() - 5);
            }
            LOG.info("SQL command: {}", sql);
            ResultSet resultSet = statement.executeQuery(sql);
            List<VehicleLifeCycleDTO> resultList = new ArrayList<>();
            while (resultSet.next()) {
                VehicleLifeCycleDTO dto = new VehicleLifeCycleDTO();

                dto.setId(resultSet.getLong(COLUMN_ID));
                dto.setVehicle(vehicleDao.findOne(resultSet.getLong(COLUMN_VEHICLE)));
                dto.setEventName(resultSet.getString(COLUMN_EVENT_NAME));
                dto.setEventDescription(resultSet.getString(COLUMN_EVENT_DESCRIPTION));
                dto.setEventDate(resultSet.getDate(COLUMN_EVENT_DATE));
                dto.setCrd(resultSet.getDate(COLUMN_CRD));
                dto.setCru(resultSet.getString(COLUMN_CRU));
                dto.setLmd(resultSet.getDate(COLUMN_LMD));
                dto.setLmu(resultSet.getString(COLUMN_LMU));
                dto.setActive(resultSet.getBoolean(COLUMN_ACTIVE));

                resultList.add(dto);
            }
            return resultList;
        } catch (SQLException e) {
            LOG.error(e.getMessage(), e);

        } finally {
            if (statement != null) {
                try {
                    statement.close();
                } catch (SQLException e) {
                    LOG.error(e.getMessage(), e);
                }
            }
        }
        return null;
    }
}
