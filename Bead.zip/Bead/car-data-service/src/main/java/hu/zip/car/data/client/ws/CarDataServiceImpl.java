package hu.zip.car.data.client.ws;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.Date;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import hu.zip.car.data.service.dto.OwnerDTO;
import hu.zip.car.data.service.dto.VehicleAccessoryDataDTO;
import hu.zip.car.data.service.dto.VehicleDTO;
import hu.zip.car.data.service.dto.VehicleLifeCycleDTO;
import hu.zip.car.data.service.dto.VehicleOwnerXtDTO;
import hu.zip.car.data.service.rest.CarDataServiceEndpoint;

@Service
public class CarDataServiceImpl implements CarDataWSClient {

	public static URI ensurePathPartEndsWithSlash(URI endpoint) {
		if (endpoint == null) {
			return null;
		}

		String path = endpoint.getRawPath();
		if (!path.endsWith("/")) {
			if (!path.startsWith("/")) {
				path = "/" + path;
			}
			endpoint = endpoint.resolve(path + "/");
		}
		return endpoint;
	}

	private RestTemplate restTemplate;
	private final URI endpoint;
	private URI ownerUri;
	private URI ownerVehiclesUri;
	private URI vehicleUri;
	private URI vehicleAccessoryDataUri;
	private URI vehicleLifeCycleUri;

	private URI vehicleOwnerXtUri;

	public CarDataServiceImpl() throws URISyntaxException {
		this.endpoint = CarDataServiceImpl.ensurePathPartEndsWithSlash(new URI("http://localhost:8444/api"));
	}

	@Override
	public String hello() {
		throw new UnsupportedOperationException("This call not supported here!");
	}

	private boolean isAllNull(Object... objs) {
		final AtomicBoolean atomicBoolean = new AtomicBoolean(true);
		Stream.of(objs).forEach(o -> atomicBoolean.set(atomicBoolean.get() && (o == null)));
		return atomicBoolean.get();
	}

	@Override
	public List<OwnerDTO> owner(Long id, String name, String address, Date birtDate, String birtPlace) {
		StringBuilder sb = new StringBuilder();
		if (!this.isAllNull(id, name, address, birtDate, birtPlace)) {
			sb.append("?");
			if (id != null) {
				sb.append("id=").append(id);
			}
			if (name != null) {
				if (!sb.toString().equals("?")) {
					sb.append("&");
				}
				sb.append("nev=").append(name);
			}
			if (address != null) {
				if (!sb.toString().equals("?")) {
					sb.append("&");
				}
				sb.append("lakcim=").append(address);
			}
			if (birtDate != null) {
				if (!sb.toString().equals("?")) {
					sb.append("&");
				}
				sb.append("szuletesiDatum=").append(CarDataServiceEndpoint.sdf.format(birtDate));
			}
			if (birtPlace != null) {
				if (!sb.toString().equals("?")) {
					sb.append("&");
				}
				sb.append("szuletesiHely=").append(birtPlace);
			}
		}
		URI getterURI = CarDataServiceImpl.ensurePathPartEndsWithSlash(this.ownerUri).resolve(sb.toString());
		OwnerDTO[] dtos = this.restTemplate.getForObject(getterURI, OwnerDTO[].class);
		return Stream.of(dtos).collect(Collectors.toList());
	}

	@Override
	public List<VehicleDTO> ownerVehicles(Long ownerId, String ownerName) {
		StringBuilder sb = new StringBuilder();
		if (!this.isAllNull(ownerId, ownerName)) {
			sb.append("?");
			if (ownerId != null) {
				sb.append("tulajdonosId=").append(ownerId);
			}
			if (ownerName != null) {
				if (!sb.toString().equals("?")) {
					sb.append("&");
				}
				sb.append("tulajdonosNeve=").append(ownerName);
			}
		}

		URI getterURI = CarDataServiceImpl.ensurePathPartEndsWithSlash(this.ownerVehiclesUri).resolve(sb.toString());
		VehicleDTO[] dtos = this.restTemplate.getForObject(getterURI, VehicleDTO[].class);
		return Stream.of(dtos).collect(Collectors.toList());
	}

	@PostConstruct
	public void postConstruct() {
		this.restTemplate = new RestTemplate();

		this.ownerUri = CarDataServiceImpl.ensurePathPartEndsWithSlash(this.endpoint).resolve("tulajdonos");
		this.ownerVehiclesUri = CarDataServiceImpl.ensurePathPartEndsWithSlash(this.endpoint).resolve("tulajdonosJarmui");
		this.vehicleUri = CarDataServiceImpl.ensurePathPartEndsWithSlash(this.endpoint).resolve("jarmu");
		this.vehicleAccessoryDataUri = CarDataServiceImpl.ensurePathPartEndsWithSlash(this.endpoint).resolve("jarmuKiegeszitoData");
		this.vehicleLifeCycleUri = CarDataServiceImpl.ensurePathPartEndsWithSlash(this.endpoint).resolve("jarmuEletut");
		this.vehicleOwnerXtUri = CarDataServiceImpl.ensurePathPartEndsWithSlash(this.endpoint).resolve("xtJarmuTulajdonos");
	}

	@Override
	public List<VehicleDTO> vehicle(Long id, String brand, String type, String kilometerPosition, String condition, String exports, Long price) {
		StringBuilder sb = new StringBuilder();
		if (!this.isAllNull(id, brand, type, kilometerPosition, condition, exports, price)) {
			sb.append("?");
			if (id != null) {
				sb.append("id=").append(id);
			}
			if (brand != null) {
				if (!sb.toString().equals("?")) {
					sb.append("&");
				}
				sb.append("marka=").append(brand);
			}
			if (type != null) {
				if (!sb.toString().equals("?")) {
					sb.append("&");
				}
				sb.append("tipus=").append(type);
			}
			if (kilometerPosition != null) {
				if (!sb.toString().equals("?")) {
					sb.append("&");
				}
				sb.append("kmallas=").append(kilometerPosition);
			}
			if (condition != null) {
				if (!sb.toString().equals("?")) {
					sb.append("&");
				}
				sb.append("allapot=").append(condition);
			}
			if (exports != null) {
				if (!sb.toString().equals("?")) {
					sb.append("&");
				}
				sb.append("kivitel=").append(exports);
			}
			if (price != null) {
				if (!sb.toString().equals("?")) {
					sb.append("&");
				}
				sb.append("ar=").append(price);
			}
		}
		URI getterURI = CarDataServiceImpl.ensurePathPartEndsWithSlash(this.vehicleUri).resolve(sb.toString());
		VehicleDTO[] dtos = this.restTemplate.getForObject(getterURI, VehicleDTO[].class);
		return Stream.of(dtos).collect(Collectors.toList());
	}

	@Override
	public List<VehicleAccessoryDataDTO> vehicleAccessoryData(Long id, Long vehicleId, String accessoryKey, String accessoryKeyDenomination,
			String accessoryValue) {
		StringBuilder sb = new StringBuilder();
		if (!this.isAllNull(id, vehicleId, accessoryKey, accessoryKeyDenomination, accessoryValue)) {
			sb.append("?");
			if (id != null) {
				sb.append("id=").append(id);
			}
			if (vehicleId != null) {
				if (!sb.toString().equals("?")) {
					sb.append("&");
				}
				sb.append("jarmuId=").append(vehicleId);
			}
			if (accessoryKey != null) {
				if (!sb.toString().equals("?")) {
					sb.append("&");
				}
				sb.append("kulcs=").append(accessoryKey);
			}
			if (accessoryKeyDenomination != null) {
				if (!sb.toString().equals("?")) {
					sb.append("&");
				}
				sb.append("kulcsMegnevezes=").append(accessoryKeyDenomination);
			}
			if (accessoryValue != null) {
				if (!sb.toString().equals("?")) {
					sb.append("&");
				}
				sb.append("kulcsErtek=").append(accessoryValue);
			}
		}

		URI getterURI = CarDataServiceImpl.ensurePathPartEndsWithSlash(this.vehicleAccessoryDataUri).resolve(sb.toString());
		VehicleAccessoryDataDTO[] dtos = this.restTemplate.getForObject(getterURI, VehicleAccessoryDataDTO[].class);
		return Stream.of(dtos).collect(Collectors.toList());
	}

	@Override
	public List<VehicleLifeCycleDTO> vehicleLifeCycle(Long id, Long vehicleId, String eventName, String eventDescription, Date eventDate) {
		StringBuilder sb = new StringBuilder();
		if (!this.isAllNull(id, vehicleId, eventName, eventDescription, eventDate)) {
			sb.append("?");
			if (id != null) {
				sb.append("id=").append(id);
			}
			if (vehicleId != null) {
				if (!sb.toString().equals("?")) {
					sb.append("&");
				}
				sb.append("jarmuId=").append(vehicleId);
			}
			if (eventName != null) {
				if (!sb.toString().equals("?")) {
					sb.append("&");
				}
				sb.append("esemenyNeve=").append(eventName);
			}
			if (eventDescription != null) {
				if (!sb.toString().equals("?")) {
					sb.append("&");
				}
				sb.append("esemenyLeirasa=").append(eventDescription);
			}
			if (eventDate != null) {
				if (!sb.toString().equals("?")) {
					sb.append("&");
				}
				sb.append("esemenyDatuma=").append(CarDataServiceEndpoint.sdf.format(eventDate));
			}
		}

		URI getterURI = CarDataServiceImpl.ensurePathPartEndsWithSlash(this.vehicleLifeCycleUri).resolve(sb.toString());
		VehicleLifeCycleDTO[] dtos = this.restTemplate.getForObject(getterURI, VehicleLifeCycleDTO[].class);
		return Stream.of(dtos).collect(Collectors.toList());
	}

	@Override
	public List<VehicleOwnerXtDTO> vehicleOwnerXt(Long id, Long vehicleId, Long ownerId, Date from, Date to) {
		StringBuilder sb = new StringBuilder();
		if (!this.isAllNull(id, vehicleId, ownerId, from, to)) {
			sb.append("?");
			if (id != null) {
				sb.append("id=").append(id);
			}
			if (vehicleId != null) {
				if (!sb.toString().equals("?")) {
					sb.append("&");
				}
				sb.append("jarmuId=").append(vehicleId);
			}
			if (ownerId != null) {
				if (!sb.toString().equals("?")) {
					sb.append("&");
				}
				sb.append("tulajdonosId=").append(ownerId);
			}
			if (from != null) {
				if (!sb.toString().equals("?")) {
					sb.append("&");
				}
				sb.append("mettol=").append(CarDataServiceEndpoint.sdf.format(from));
			}
			if (to != null) {
				if (!sb.toString().equals("?")) {
					sb.append("&");
				}
				sb.append("meddig=").append(CarDataServiceEndpoint.sdf.format(to));
			}
		}

		URI getterURI = CarDataServiceImpl.ensurePathPartEndsWithSlash(this.vehicleOwnerXtUri).resolve(sb.toString());
		VehicleOwnerXtDTO[] dtos = this.restTemplate.getForObject(getterURI, VehicleOwnerXtDTO[].class);
		return Stream.of(dtos).collect(Collectors.toList());
	}

}
