package hu.zip.car.data.service.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import hu.zip.car.data.service.dto.VehicleOwnerXtDTO;

@Service
public class VehicleOwnerXtDao {

    private static final Logger LOG = LoggerFactory.getLogger(VehicleDao.class);
    private static final SimpleDateFormat SDF = new SimpleDateFormat("yyyy-MM-dd");

    public static final String TABLE_NAME = "XT_JARMU_TULAJDONOS";
    public static final String COLUMN_ID = "ID";
    public static final String COLUMN_VEHICLE = "JARMU_ID";
    public static final String COLUMN_OWNER = "TULAJDONOS_ID";
    public static final String COLUMN_FROM = "METTOL";
    public static final String COLUMN_TO = "MEDDIG";
    public static final String COLUMN_CRD = "CRD";
    public static final String COLUMN_CRU = "CRU";
    public static final String COLUMN_LMD = "LMD";
    public static final String COLUMN_LMU = "LMU";
    public static final String COLUMN_ACTIVE = "AKTIV";

    @Qualifier("mysqlConncetion")
    @Autowired
    private Connection con;

    @Autowired
    private VehicleDao vehicleDao;

    @Autowired
    private OwnerDao ownerDao;

    /**
     *
     * @param id Tabla azonosito.
     * @param vehicleId JARMU azonosito.
     * @param ownerId TULAJDONOS azonosito
     * @param from Mikortol tartozik a jarmu a TUJALDONOS-hoz
     * @param to Meddig volt a jarmu a TULAJDONOS birtokaban.
     * @return Egy lista a JARMU-TULAJDONOS kapcsolatokrol.
     */
    public List<VehicleOwnerXtDTO> findByParams(Long id, Long vehicleId, Long ownerId, Date from, Date to) {
        Statement statement = null;
        try {
            statement = this.con.createStatement();
            StringBuilder sb = new StringBuilder();
            sb.append("SELECT * FROM ").append(TABLE_NAME);

            if (Objects.nonNull(id) || Objects.nonNull(vehicleId)//
                    || Objects.nonNull(ownerId)//
                    || Objects.nonNull(from)//
                    || Objects.nonNull(to)//
                    ) {
                sb.append(" WHERE ");
            }
            if (Objects.nonNull(id)) {
                sb.append(COLUMN_ID).append("=").append(id);
                sb.append(" AND ");
            }
            if (Objects.nonNull(vehicleId)) {
                sb.append(COLUMN_VEHICLE).append("=").append(vehicleId);
                sb.append(" AND ");
            }
            if (Objects.nonNull(ownerId)) {
                sb.append(COLUMN_VEHICLE).append("=").append(ownerId);
                sb.append(" AND ");
            }
            if (Objects.nonNull(from)) {
                sb.append(COLUMN_FROM).append(" BETWEEN \"")//
                        .append(SDF.format(from)).append("\" DATE(CURRENT_DATE)");
                sb.append(" AND ");
            }
            if (Objects.nonNull(to)) {
                sb.append(COLUMN_TO).append(" BETWEEN \"")//
                        .append(SDF.format(to)).append("\" DATE(CURRENT_DATE)");
            }

            String sql = sb.toString();
            if (sql.endsWith(" AND ")) {
                sql = sql.substring(0, sql.length() - 5);
            }
            LOG.info("SQL command: {}", sql);
            ResultSet resultSet = statement.executeQuery(sql);
            List<VehicleOwnerXtDTO> resultList = new ArrayList<>();
            while (resultSet.next()) {
                VehicleOwnerXtDTO dto = new VehicleOwnerXtDTO();

                dto.setId(resultSet.getLong(COLUMN_ID));
                dto.setVehicle(vehicleDao.findOne(resultSet.getLong(COLUMN_VEHICLE)));
                dto.setOwner(ownerDao.findOne(resultSet.getLong(COLUMN_OWNER)));
                dto.setFrom(resultSet.getDate(COLUMN_FROM));
                dto.setTo(resultSet.getDate(COLUMN_TO));
                dto.setCrd(resultSet.getDate(COLUMN_CRD));
                dto.setCru(resultSet.getString(COLUMN_CRU));
                dto.setLmd(resultSet.getDate(COLUMN_LMD));
                dto.setLmu(resultSet.getString(COLUMN_LMU));
                dto.setActive(resultSet.getBoolean(COLUMN_ACTIVE));

                resultList.add(dto);
            }
            return resultList;
        } catch (SQLException e) {
            LOG.error(e.getMessage(), e);

        } finally {
            if (statement != null) {
                try {
                    statement.close();
                } catch (SQLException e) {
                    LOG.error(e.getMessage(), e);
                }
            }
        }
        return null;
    }
}
