package hu.zip.car.data;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.context.ConfigurableApplicationContext;

import com.google.common.collect.ImmutableMap;

/**
 *
 * Spring-Boot konfiguracioja. Indito osztaly. A Spring/Boot egy 8.0.15
 * Tomcat-et is hordoz igy nem kell neki kulon telepiteni hozza egy szervert.
 */
@SpringBootApplication
public class Application {

	public static void main(String[] args) {
		new Application().run(args);
	}

	/**
	 * Spring configuracios classok listaja amit majd beolvas mikor indul a
	 * spring-boot es letrehozza a bean-ket es szervizeket.
	 */
	private Class<?>[] getConfigurations() {
		return new Class<?>[] { ApplicationModuleConfig.class };
	}

	public ConfigurableApplicationContext run(String[] args) {
		// Minimalis config. Port es kibindolom az osszes IP-re a gepen.
		return new SpringApplicationBuilder().properties(//
				ImmutableMap.<String, Object>builder()//
						.put("server.port", 8444)//
						.put("server.address", "0.0.0.0") //
						.build()//
		).sources(this.getConfigurations())//
				.build().run(args);
	}

}
