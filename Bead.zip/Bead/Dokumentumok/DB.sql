SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

DROP TABLE IF EXISTS JARMU;

DROP TABLE IF EXISTS JARMU_ELETUT;

DROP TABLE IF EXISTS JARMU_KIEGESZITO_DATA;

DROP TABLE IF EXISTS TULAJDONOS;

DROP TABLE IF EXISTS XT_JARMU_TULAJDONOS;

/*==============================================================*/
/* Table: JARMU                                                 */
/*==============================================================*/
CREATE TABLE JARMU
(
   ID                   INT NOT NULL AUTO_INCREMENT COMMENT 'A tábla egydi azonosítója',
   MARKA                VARCHAR(100) CHARACTER SET UTF8 COMMENT 'A jármű márkája',
   TÍPUS                VARCHAR(100) CHARACTER SET UTF8 COMMENT 'A jármű típusa',
   KM_ALLAS             INT COMMENT 'A km óra állása',
   ALLAPOT              VARCHAR(100) CHARACTER SET UTF8 COMMENT 'A jármű állapota',
   KIVITEL              VARCHAR(100) CHARACTER SET UTF8 COMMENT 'A jármű kivitele',
   AR                   INT COMMENT 'A jármű ára',
   CRD                  TIMESTAMP NOT NULL COMMENT 'A rekord létrehozásának dátuma',
   CRU                  VARCHAR(100) CHARACTER SET UTF8 NOT NULL COMMENT 'A rekordot létrehozó felhasználó azonosítója',
   LMD                  TIMESTAMP NOT NULL COMMENT 'A rekord utilsó módosításának dátuma',
   LMU                  VARCHAR(100) CHARACTER SET UTF8 NOT NULL COMMENT 'A rekordot utoljára módosító felhasználó azonosítója',
   AKTIV                TINYINT(1) NOT NULL COMMENT 'A rekord aktív-e? 1=igen, 0=nem',
   PRIMARY KEY (ID)
)
ENGINE=INNODB  DEFAULT CHARSET=UTF8 COLLATE=UTF8_HUNGARIAN_CI AUTO_INCREMENT=7;

ALTER TABLE JARMU COMMENT 'A gépjármű alap adatait tároló tábla.';

/*==============================================================*/
/* Table: JARMU_ELETUT                                          */
/*==============================================================*/
CREATE TABLE JARMU_ELETUT
(
   ID                   INT NOT NULL COMMENT 'A tábla egydi azonosítója',
   JARMU_ID             INT COMMENT 'A JARMU tábla egyedi azonosítója',
   ESEMENY_NEVE         VARCHAR(100) CHARACTER SET UTF8 NOT NULL COMMENT 'Az esemény neve',
   ESEMENY_LEIRAS       VARCHAR(500) CHARACTER SET UTF8 NOT NULL COMMENT 'Az esemény leírása',
   ESEMENY_DATUMA       DATE NOT NULL COMMENT 'Az esemény bekövetkezésének dátuma',
   CRD                  TIMESTAMP NOT NULL COMMENT 'A rekord létrehozásának dátuma',
   CRU                  VARCHAR(100) CHARACTER SET UTF8 NOT NULL COMMENT 'A rekordot létrehozó felhasználó azonosítója',
   LMD                  TIMESTAMP NOT NULL COMMENT 'A rekord utilsó módosításának dátuma',
   LMU                  VARCHAR(100) CHARACTER SET UTF8 NOT NULL COMMENT 'A rekordot utoljára módosító felhasználó azonosítója',
   AKTIV                TINYINT(1) NOT NULL COMMENT 'A rekord aktív-e? 1=igen, 0=nem',
   PRIMARY KEY (ID)
)
ENGINE=INNODB  DEFAULT CHARSET=UTF8 COLLATE=UTF8_HUNGARIAN_CI AUTO_INCREMENT=7;

ALTER TABLE JARMU_ELETUT COMMENT 'A jármű életútjával kapcsolatos főbb eseményeket tároló tábl';

/*==============================================================*/
/* Table: JARMU_KIEGESZITO_DATA                                 */
/*==============================================================*/
CREATE TABLE JARMU_KIEGESZITO_DATA
(
   ID                   INT NOT NULL COMMENT 'A tábla egydi azonosítója',
   JARMU_ID             INT COMMENT 'A JARMU tábla egyedi azonosítója',
   KULCS                VARCHAR(100) CHARACTER SET UTF8 NOT NULL COMMENT 'A tulajdonság kulcsa',
   KULCS_MEGNEVEZES     VARCHAR(100) CHARACTER SET UTF8 NOT NULL COMMENT 'A tulajdomság megnevezése',
   KULCS_ERTEK          VARCHAR(250) CHARACTER SET UTF8 NOT NULL COMMENT 'A tulajdonság értéke',
   CRD                  TIMESTAMP NOT NULL COMMENT 'A rekord létrehozásának dátuma',
   CRU                  VARCHAR(100) CHARACTER SET UTF8 NOT NULL COMMENT 'A rekordot létrehozó felhasználó azonosítója',
   LMD                  TIMESTAMP NOT NULL COMMENT 'A rekord utilsó módosításának dátuma',
   LMU                  VARCHAR(100) CHARACTER SET UTF8 NOT NULL COMMENT 'A rekordot utoljára módosító felhasználó azonosítója',
   AKTIV                TINYINT(1) NOT NULL COMMENT 'A rekord aktív-e? 1=igen, 0=nem',
   PRIMARY KEY (ID)
)
ENGINE=INNODB  DEFAULT CHARSET=UTF8 COLLATE=UTF8_HUNGARIAN_CI AUTO_INCREMENT=7;

ALTER TABLE JARMU_KIEGESZITO_DATA COMMENT 'A jármű extra,kiegészítő adatit tároló tábla.';

/*==============================================================*/
/* Table: TULAJDONOS                                            */
/*==============================================================*/
CREATE TABLE TULAJDONOS
(
   ID                   INT NOT NULL AUTO_INCREMENT COMMENT 'A tábla egydi azonosítója',
   NEV                  VARCHAR(250) CHARACTER SET UTF8 NOT NULL COMMENT 'A tulajdonos neve',
   LAKCIM               VARCHAR(250) CHARACTER SET UTF8 COMMENT 'A tulajdonos állandó lakcíme',
   SZULETESI_DATUM      DATE COMMENT 'A tulajdonos születési dátuma',
   SZULETESI_HELY       VARCHAR(100) CHARACTER SET UTF8 COMMENT 'A tulajdonos születési helye',
   CRD                  TIMESTAMP NOT NULL COMMENT 'A rekord létrehozásának dátuma',
   CRU                  VARCHAR(100) CHARACTER SET UTF8 NOT NULL COMMENT 'A rekordot létrehozó felhasználó azonosítója',
   LMD                  TIMESTAMP NOT NULL COMMENT 'A rekord utilsó módosításának dátuma',
   LMU                  VARCHAR(100) CHARACTER SET UTF8 NOT NULL COMMENT 'A rekordot utoljára módosító felhasználó azonosítója',
   AKTIV                TINYINT(1) NOT NULL COMMENT 'A rekord aktív-e? 1=igen, 0=nem',
   PRIMARY KEY (ID)
)
ENGINE=INNODB  DEFAULT CHARSET=UTF8 COLLATE=UTF8_HUNGARIAN_CI AUTO_INCREMENT=7;

ALTER TABLE TULAJDONOS COMMENT 'A tulajdonos adatait tároló tábla.';

/*==============================================================*/
/* Table: XT_JARMU_TULAJDONOS                                   */
/*==============================================================*/
CREATE TABLE XT_JARMU_TULAJDONOS
(
   ID                   INT NOT NULL AUTO_INCREMENT COMMENT 'A tábla egydi azonosítója',
   JARMU_ID             INT NOT NULL COMMENT 'A JARMU tábla egyedi azonosítója.',
   TULAJDONOS_ID        INT NOT NULL COMMENT 'A TULAJDONOS tábla egyedi azonosítója',
   METTOL               DATE NOT NULL COMMENT 'Mikortól bitrokolja a tulajdonos a járművet',
   MEDDIG               DATE COMMENT 'Meddig birtokolta a  tulajdonos a járművet',
   CRD                  TIMESTAMP NOT NULL COMMENT 'A rekord létrehozásának dátuma',
   CRU                  VARCHAR(100) CHARACTER SET UTF8 NOT NULL COMMENT 'A rekordot létrehozó felhasználó azonosítója',
   LMD                  TIMESTAMP NOT NULL COMMENT 'A rekord utilsó módosításának dátuma',
   LMU                  VARCHAR(100) CHARACTER SET UTF8 NOT NULL COMMENT 'A rekordot utoljára módosító felhasználó azonosítója',
   AKTIV                TINYINT(1) NOT NULL COMMENT 'A rekord aktív-e? 1=igen, 0=nem',
   PRIMARY KEY (ID)
)
ENGINE=INNODB  DEFAULT CHARSET=UTF8 COLLATE=UTF8_HUNGARIAN_CI AUTO_INCREMENT=7;

ALTER TABLE XT_JARMU_TULAJDONOS COMMENT 'A tulajdonos és a jármű közötti kapcsolatot tároló tábla.';

ALTER TABLE JARMU_ELETUT ADD CONSTRAINT JARMUELETUT_JARMU_JARMUID_FK FOREIGN KEY (JARMU_ID)
      REFERENCES JARMU (ID);

ALTER TABLE JARMU_KIEGESZITO_DATA ADD CONSTRAINT JKD_JARMU_JARMUID_FK FOREIGN KEY (JARMU_ID)
      REFERENCES JARMU (ID);

ALTER TABLE XT_JARMU_TULAJDONOS ADD CONSTRAINT XTJT_JARMU_JARMUID_FK FOREIGN KEY (JARMU_ID)
      REFERENCES JARMU (ID);

ALTER TABLE XT_JARMU_TULAJDONOS ADD CONSTRAINT XTJT_TULAJ_TULAJID_FK FOREIGN KEY (TULAJDONOS_ID)
      REFERENCES TULAJDONOS (ID);
